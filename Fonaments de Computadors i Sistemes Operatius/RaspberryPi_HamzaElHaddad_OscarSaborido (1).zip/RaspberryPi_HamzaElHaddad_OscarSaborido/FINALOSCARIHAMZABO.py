import RPi.GPIO as GPIO
import time
from RPLCD.i2c import CharLCD

# configuració bàsica del GPIO
GPIO.setmode(GPIO.BCM)   # fem servir numeració BCM (no BOARD)
GPIO.setwarnings(False)  # desactivem els avisos perquè a vegades molesten si tornes a executar

# LEDs per al semàfor
led_verd = 17      # llum verda -> cotxes poden passar
led_groc = 27      # llum groga -> avís que canviarà
led_vermell = 23   # llum vermella -> stop per als cotxes

# sensor ultrasònic HC-SR04
trig = 22          # aquest envia el senyal
echo = 24          # aquest rep el rebote

# buzzer per fer soroll
bip = 18           # sona cada segon del compte enrere

# configurar pins com a sortida o entrada
GPIO.setup(led_verd, GPIO.OUT)
GPIO.setup(led_groc, GPIO.OUT)
GPIO.setup(led_vermell, GPIO.OUT)
GPIO.setup(trig, GPIO.OUT)
GPIO.setup(echo, GPIO.IN)
GPIO.setup(bip, GPIO.OUT)

# configurar la pantalla LCD (va per I2C)
lcd = CharLCD('PCF8574', 0x27, port=1, cols=16, rows=2)
lcd.clear()  # netegem qualsevol cosa que hi hagués abans

# aquesta funció mesura la distància del sensor
def agafa_distancia():
    # enviem pols d'ultrasons
    GPIO.output(trig, False)
    time.sleep(0.05)  # esperem un moment per estabilitzar

    GPIO.output(trig, True)  # inici senyal
    time.sleep(0.00001)      # molt curt
    GPIO.output(trig, False) # parem

    inici = time.time()  # guardem quan comença
    timeout = inici + 0.04  # per si es queda penjat (seguretat)
    
    while GPIO.input(echo) == 0 and time.time() < timeout:
        inici = time.time()  # espera que comenci el rebote

    final = time.time()
    timeout = final + 0.04  # mateix timeout per l'altre bucle
    while GPIO.input(echo) == 1 and time.time() < timeout:
        final = time.time()  # quan rep el rebote

    durada = final - inici  # quant ha trigat el senyal a tornar
    distancia = durada * 17150  # fórmula per convertir-ho a cm

    return round(distancia, 2)  # només dos decimals (més no cal)

# aquí fem el compte enrere a la pantalla
def compte_enrere():
    lcd.clear()
    lcd.write_string("Peaton pasando")  # primer missatge
    time.sleep(1)  # pausa abans de començar
    
    for i in range(10, 0, -1):  # de 10 a 1 (no inclou 0)
        lcd.clear()
        lcd.write_string("Cuenta atras: " + str(i))  # ex: Falten: 9
        GPIO.output(bip, True)   # encenem bip curt
        time.sleep(0.1)
        GPIO.output(bip, False)
        time.sleep(0.9)  # que el total sigui 1 segon

    lcd.clear()  # quan s’acaba, netegem pantalla

# bucle principal
try:
    while True:
        d = agafa_distancia()  # cada volta mirem la distància
        print("Distancia actual:", d, "cm")  # només per comprovar al terminal

        # si detectem un objecte a menys de 10cm (com una mà aprop)
        if d < 10:
            # primer apaguem la verda per si està encesa
            GPIO.output(led_verd, False)

            # encenem groga i bip (avís)
            GPIO.output(led_groc, True)
            GPIO.output(bip, True)
            time.sleep(2)  # 2 segons d’avís
            GPIO.output(led_groc, False)
            GPIO.output(bip, False)

            # ara encenem vermell per parar cotxes
            GPIO.output(led_vermell, True)
            compte_enrere()  # fem compte enrere amb missatge LCD
            GPIO.output(led_vermell, False)  # ja pot tornar al verd després

        else:
            # si no detectem res, semàfor en verd (intermitent per estalviar energia?)
            GPIO.output(led_verd, True)
            time.sleep(0.1)
            GPIO.output(led_verd, False)

except KeyboardInterrupt:
    # si apretem Ctrl+C, netegem GPIO i LCD
    GPIO.cleanup()
    lcd.clear()
    lcd.write_string("fi del programa")  # missatge simpàtic
